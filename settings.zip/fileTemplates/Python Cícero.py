# -*- coding: utf-8 -*-
"""${FILE_NAME} in: ${DATE}.
Python version: 3.10.0

"""


def main():
    pass


if __name__ == '__main__':
    main()
